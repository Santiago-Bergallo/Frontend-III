 
// export const GlobalStyles = 
// <body></body>
//   html, body {
//     padding: 0;
//     margin: 0;
//     box-sizing: border-box;
//     background: #e5e5e5;
//     font-family: sans-serif;
//   }
// ;