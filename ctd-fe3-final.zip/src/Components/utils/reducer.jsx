

// export const reducer = (state, action) => {
//     switch(action.type) {
//         case 'DARK_MODE':
//             return {theme: state.theme === "dark"}
//         case 'LIGHT_MODE':
//             return {theme: (state.theme === "")}
//         // default:
//         // throw new Error()
//   }
// }