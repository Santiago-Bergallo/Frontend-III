import { createContext, useContext, useEffect, useState, useReducer } from "react";
import { theme } from "../Theme";
import axios from "axios";


export const initialState = {theme: "", data: []}
export const ContextGlobal = createContext();
export const ContextProvider = ({ children }) => {
  
  const [data, setData] = useState([])
  const url = 'https://jsonplaceholder.typicode.com/users'
  
  
  
const [theme, setTheme] = useState(initialState)



const handleTheme = () => {
  theme === ''? setTheme('dark') : setTheme('')
}



  useEffect(() => {
    axios(url)
    .then(res => setData(res.data))
  
  }, [])
  

  return (
    <ContextGlobal.Provider value={{
        data,
        setData,
        theme,
        setTheme,
        handleTheme,

    }}>
      {children}
    </ContextGlobal.Provider>
  );

};

export default ContextProvider;

export const useEstadosGlobales = () => {
  return useContext(ContextGlobal)
}

